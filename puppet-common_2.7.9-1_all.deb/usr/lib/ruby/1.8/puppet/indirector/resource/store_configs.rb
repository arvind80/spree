require 'puppet/indirector/store_configs'
class Puppet::Resource::StoreConfigs < Puppet::Indirector::StoreConfigs
end
