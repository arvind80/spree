require 'puppet/indirector/status'
require 'puppet/indirector/rest'

class Puppet::Indirector::Status::Rest < Puppet::Indirector::REST
end
