module Puppet::Util::Ldap
end
