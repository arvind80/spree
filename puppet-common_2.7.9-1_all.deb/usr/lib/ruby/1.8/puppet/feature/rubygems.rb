require 'puppet/util/feature'

Puppet.features.add(:rubygems, :libs => "rubygems")
